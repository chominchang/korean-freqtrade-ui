import{H as o,c as t,a as n,e as r}from"./index-DxWFWf6T.js";const a={viewBox:"0 0 24 24",width:"1.2em",height:"1.2em"};function c(l,e){return n(),t("svg",a,e[0]||(e[0]=[r("path",{fill:"currentColor",d:"M21 7L9 19l-5.5-5.5l1.41-1.41L9 16.17L19.59 5.59z"},null,-1)]))}const i=o({name:"mdi-check",render:c});export{i as _};
//# sourceMappingURL=check-BbeoMY0n.js.map
